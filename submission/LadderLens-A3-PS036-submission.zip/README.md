# LadderLens

### Making post-quantum DNS signatures practical to reason about.

**What if a DNS zone could pay the cost of one post-quantum signature once, then answer each later query with a tiny proof?** LadderLens measures that idea using Merkle Tree Ladder (MTL) signatures: same records, same cryptographic library, three signing strategies, and a reproducible benchmark.

<p align="center">
  <a href="#the-result"><strong>See the results</strong></a> ·
  <a href="#how-the-ladder-works">Understand MTL</a> ·
  <a href="#reproduce-the-benchmark">Run the benchmark</a> ·
  <a href="results/final/report.md">Explore the full report</a>
</p>

<p align="center">
  <img src="results/final/charts/answer_sizes.png" alt="Chart comparing plain and MTL signature sizes" width="48%">
  <img src="results/final/charts/verification.png" alt="Chart comparing cold and warm verification times" width="48%">
</p>

> **The headline:** At 1,000 RRsets, one MTL batch was signed in **929 ms**; a warm MTL answer verified in **6.6 μs** and carried at most **220 bytes of signature material**. The same plain SLH-DSA workload carries **7,856 bytes per signature**.

## The result

LadderLens evaluates SLH-DSA-SHA2-128s and Verisign's MTL reference implementation across zones of 10, 100 and 1,000 RRsets.

<table>
  <tr><th align="left">At N = 1,000</th><th align="left">Plain SLH-DSA</th><th align="left">MTL batch of 1,000</th></tr>
  <tr><td>Signing the zone</td><td>944.85 s (extrapolated)</td><td><strong>929.3 ms</strong></td></tr>
  <tr><td>Warm answer verification</td><td>845.7 μs</td><td><strong>6.6 μs</strong></td></tr>
  <tr><td>Signature carried per answer</td><td>7,856 B</td><td><strong>≤ 220 B</strong> after ladder retrieval</td></tr>
  <tr><td>Complete encoded DNS response</td><td>up to 8,100 B</td><td><strong>up to 464 B</strong> with cached ladder</td></tr>
</table>

<p align="center"><img src="results/final/charts/signing.png" alt="Measured and estimated signing times for plain SLH-DSA and MTL" width="75%"></p>

<details>
<summary><strong>What does “warm” mean? Where does the 1,000-record estimate come from?</strong></summary>

Warm verification means the resolver has already checked and cached the signed ladder. It then verifies each answer using the compact authentication proof. The one-time ladder check at N=1,000 measured 843.2 μs.

The plain 1,000-record total is an extrapolation from 100 records timed per trial; the MTL batch-of-one total is likewise extrapolated. The MTL batch-of-1,000 result is directly measured. All three dataset sizes and the current byte-reporting interpretation were mentor-approved. Detailed methods, trial counts, confidence intervals, and every result are in the [full benchmark report](results/final/report.md).
</details>

## How the ladder works

Think of a ladder as a **signed table of contents** for a batch of DNS records. The zone signs the table once. Each answer then carries a short proof showing where its record belongs in that signed batch.

```mermaid
flowchart LR
    A[Zone records] --> B[Sign one shared ladder]
    B --> C[Resolver checks ladder once]
    C --> D[Cache ladder]
    D --> E[Each later answer carries a compact proof]
    E --> F[Fast warm verification]
```

On the first lookup, the resolver needs the full signed ladder. After it has validated and cached that ladder, later answers can use condensed signatures. This makes the central engineering question measurable: **how much does MTL save when the ladder is reused, and what does that one-time cost look like?**

## A fair, repeatable comparison

Every arm signs the same reproducibly generated DNS RRsets with the same underlying SLH-DSA algorithm.

| Benchmark arm | What it does | Why it is included |
|---|---|---|
| **A · Plain** | One plain SLH-DSA signature per RRset | Baseline without MTL |
| **B · MTL-1** | One MTL batch per record | Shows the cost when no records share a ladder |
| **C · MTL-N** | One signed ladder for the full zone; one condensed proof per record | Measures MTL's shared-batch design |

The harness records signing and verification time, signature bytes, and locally encoded DNS response sizes. A resolver replay measures ladder-cache hits, misses, and bytes over synthetic query streams. Repeated trials interleave the arms in randomized order; the report keeps measured, extrapolated, analytical, and specification-derived values labeled separately.

<p align="center">
  <img src="results/final/charts/dns_response_sizes.png" alt="Encoded DNS response sizes for plain, full MTL, and condensed MTL responses" width="48%">
  <img src="results/final/charts/cache_hits.png" alt="Resolver cache hit behavior across the replay scenarios" width="48%">
</p>

### What the byte measurements show

For N=1,000, the largest locally encoded response carrying a condensed MTL signature is **464 B**, within the 1,232-byte EDNS payload used in the experiment. The first response, when the resolver does not yet have the ladder, carries the full ladder and reaches **8,552 B**. MTL's byte savings therefore come from reuse; the report quantifies both the first-fetch cost and later compact answers.

The project reports three scopes distinctly: signature material, complete DNS messages encoded locally, and network traffic. The benchmark covers the first two; it does not claim to capture live network traffic.

## Reproduce the benchmark

The pinned Docker image supplies OpenSSL 3.6.0, liboqs 0.16.0, and Verisign MTL v1.3.1. GNU Make provides short commands for building, checking, and running the experiment.

```sh
make build       # build the pinned benchmark image
make verify      # cryptographic self-test, sizes, DNS encoding and result checks
make test        # unit and end-to-end tests
make smoke       # smoke-check the reference command-line tools
make demo        # narrated project walkthrough
make plan        # pilot and trial plan
make bench RUN=results/my-run
make report RUN=results/my-run
```

To explore the recorded benchmark without running it again, open the [report](results/final/report.md), browse the [raw results and manifest](results/final/), or launch the optional dashboard with `make dashboard`.

### Validation snapshot

- Pinned Docker image built successfully; the C harness compiled in the image.
- Docker `make verify` passed the cryptographic self-test and all correctness and sizing checks.
- Docker `make test` passed **21 tests**, including end-to-end coverage.
- The retained performance run contains **216/216 completed trials** and **15/15 cache replays**; it ran on the recorded native WSL2 host. Docker validation checked the pinned image separately. The raw data and environment manifest are included.

## Explore the project

- [Final audit and PS-036 readiness](docs/FINAL-AUDIT-2026-10-25.md)
- [PS-036 page 1 compliance matrix](docs/PS036-COMPLIANCE.md)
- [Team Nexora presentation PDF](output/pdf/AIORI-3-PS036-Nexora.pdf)
- [Validation log index](docs/validation/README.md)

| Want to… | Go to… |
|---|---|
| See every result, chart, confidence interval, and configuration detail | [Full benchmark report](results/final/report.md) |
| Understand how the measurements are produced | [Methodology](docs/METHODOLOGY.md) |
| Review the PS-036 requirement mapping | [PS-036 compliance](docs/PS036-COMPLIANCE.md) |
| Inspect the source and run metadata | [Final run data and manifest](results/final/) |
| Review the assignment mapping and methodology | [PS-036 compliance](docs/PS036-COMPLIANCE.md) · [Methodology](docs/METHODOLOGY.md) |
| Try the interactive run dashboard | `make dashboard` |

<details>
<summary><strong>Technical notes for reviewers</strong></summary>

- **Algorithm:** SLH-DSA-SHA2-128s with MTL-SHA2-128.
- **Reference implementation:** Verisign MTL v1.3.1, pinned to commit `7cef0191da55048111d252a567b7614672424ed3`.
- **Workload:** deterministic synthetic A, AAAA, TXT and MX RRsets at N=10, 100 and 1,000.
- **Timing:** `CLOCK_MONOTONIC`; repeated trials are planned and interleaved by arm.
- **Resolver model:** a C replay harness exercises cache expiry and zone growth; an analytical model is reported alongside the measured replay.
- **Integrity:** each run records configuration, environment, dependency versions, and hashes for raw measurements, per-run metadata, cache replay outputs, and the invocation schedule.
- **Scope:** benchmark and analysis of an existing cryptographic implementation; no new cryptography, production resolver, or security claim.

</details>

## Why LadderLens

Post-quantum cryptography brings stronger long-term security goals—and signatures large enough to challenge the DNS response sizes the Internet relies on. LadderLens makes the MTL trade-off concrete with an end-to-end, reproducible experiment: cryptographic operations, DNS encoding, resolver cache behavior, and readable results in one project.

Built for the **AIORI-3 Hackathon · PS-036**.


<details>
<summary><strong>Generated summary from a completed benchmark run</strong></summary>

<!-- results:start -->
From the final run ([full report](results/final/report.md), [raw data and manifest](results/final/)):

- Signing 1,000 RRsets took 929.3 ms as one MTL batch (measured) against 944.85 s with plain SLH-DSA (extrapolated): one SLH-DSA signature instead of 1,000.
- With the ladder cached, a resolver verifies an answer in 6.6 µs against 845.7 µs for plain SLH-DSA (measured); the ladder itself costs 843.2 µs to check once.
- At N = 1,000, every condensed answer encodes to at most 464 B and fits 1,232 B; an answer without a cached ladder needs up to 8,552 B, more than plain SLH-DSA (8,100 B). The saving depends on ladder reuse (analytical).
- In the resolver replay with a 5,000-query ladder lifetime, 99.98% of answers were served from the cached ladder at 208 B of signature per query (measured; model 99.98%).
<!-- results:end -->

</details>
